package Listener;



import com.example.myrecycler.Item;

public interface onClickListeners {
    void onItemCLickListener(Item item);


}
